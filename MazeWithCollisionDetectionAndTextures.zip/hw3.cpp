//Jamie Wyatt
//11-07-2018
//Homework 3
//INTRO TO GRAPHICS-------3D MAZE / COLLISION DETECTIONS / TEXTURES

#include <GL/glut.h>
#include <gl/freeglut.h>
#include <math.h>
#include <time.h>
#include "RGBpixmap.h"

RGBpixmap pix[20];    // make six pixmaps
float xAngle = 0.0;
float yAngle = 0.0;

bool a_key_down = false;
bool firstrun = true;
GLdouble eyeX = 0;
GLdouble eyeY = 0;
GLdouble eyeZ = -5;
GLdouble centerX = 0;
GLdouble centerY = 0;
GLdouble centerZ = 0;
GLdouble upX = 0;
GLdouble upY = 1;
GLdouble upZ = 0;
float xrot = 1;

float movement = 7.0;

float angle = 0.0;
float lx = 0.0f, lz = -1.0f, ly = 0.0;
float x = 0.0f, z = 0.0f;

float x2Angle;
float y2Angle;
float h = 0;

void spinner(int j) {
	float xSpeed = 2.0 / (j + 1);
	float ySpeed = 1.0 / (j + 1);
	x2Angle += xSpeed;
	y2Angle += ySpeed; h += 1;
	if (h > 360) h -= 360;
	glutPostRedisplay();
}

//////////////////////////////////////KEYBOARD FUNCTION
void keyboard(unsigned char key, int x, int y) { //see if user pressed q
	if (key == 'q') a_key_down = true;

}
bool VerticalWall;

bool WallCheck(int xBottom, int xTop, int zBottom, int zTop) {
	int Padding = 10;
	if (xBottom == xTop) {
		VerticalWall = true;
	}
	else VerticalWall = false;

	if (VerticalWall) {
		if (x < xBottom + Padding && x > xBottom && z < zTop && z > zBottom) {
			x = xBottom + Padding;
			return true;
		}if (x > xBottom - Padding && x < xBottom && z < zTop && z > zBottom) {
			x = xBottom - Padding;
			return true;
		}
	}
	else {
		if (z < zBottom + Padding && z > zBottom && x < xTop && x > xBottom) {
			z = zBottom + Padding;
			return true;
		}if (z > zBottom - Padding && z < zBottom && x < xTop && x > xBottom) {
			z = zBottom - Padding;
			return true;
		}
	}

	return false;
}

bool CheckCollision() {
	if(x > 1000){
		x = 999;	
		return true;
	}
	if (z > 1000) {
		z = 999;
		return true;
	}if (x < -1000) {
		x = -999;
		return true;
	}if (z < -1000) {
		z = -999;
		return true;
	}

	bool ret;

	//LeftWall
	if (WallCheck(-800, -800, -800, 800) == true) return true;
	//RightWall
	if (WallCheck(800, 800, -800, 800) == true) return true;
	//Front 1
	if (WallCheck(-800, -160, -800, -800) == true) return true;
	//Front 2
	if (WallCheck(160, 800, -800, -800) == true) return true;
	//Back 1
	if (WallCheck(-800, -160, 800, 800) == true) return true;
	//Back 2
	if (WallCheck(160, 800, 800, 800) == true) return true;
	//v1
	if (WallCheck(-480, -480, 480, 800) == true) return true;
	//v2
	if (WallCheck(160, 160, 480, 800) == true) return true;
	//v3
	if (WallCheck(-160, -160, -800, 480) == true) return true;
	//v4
	if (WallCheck(480, 480, -800, 480) == true) return true;
	//v5
	if (WallCheck(-480, -480, -480, -160) == true) return true;
	//v6
	if (WallCheck(160, 160, -480, -160) == true) return true;
	//h1
	if (WallCheck(-480, -160, 160, 160) == true) return true;
	//h2
	if (WallCheck(160, 480, 160, 160) == true) return true;
	//h3
	if (WallCheck(-800, -480, -160, -160) == true) return true;
	//h4
	if (WallCheck(-160, 160, -480, -480) == true) return true;

	return false;
}

void SpecialInput(int key, int t, int y)
{

	bool collide = CheckCollision();

	if (key == GLUT_KEY_UP && collide == false) {
	x += lx * movement;
	z += lz * movement;
}
	if (key == GLUT_KEY_DOWN && collide == false) {
		x -= lx * movement;
		z -= lz * movement;
	}
		if (key == GLUT_KEY_UP && collide == true) {
		
			if (VerticalWall) {
				if (cos(angle) > 0 && cos(angle) < 1)
				{
					z -= movement;
				}
				else
					z += movement;
			}
			else {
				if (sin(angle) > 0 && sin(angle) < 1)
				{
					x += movement;
				}
				else
					x -= movement;
			}

			
		}
		if (key == GLUT_KEY_DOWN && collide == true) {
			if (VerticalWall) {
				if (cos(angle) > 0 && cos(angle) < 1)
				{
					z += movement;
				}
				else
					z -= movement;
			}
			else {
				if (sin(angle) > 0 && sin(angle) < 1)
				{
					x -= movement;
				}
				else
					x += movement;
			}
}
		if (key == GLUT_KEY_LEFT) {
		angle -= 0.1;
		lx = sin(angle);
		lz = -cos(angle);
}
		if (key == GLUT_KEY_RIGHT) {
			angle += 0.1;
			lx = sin(angle);
			lz = -cos(angle);
		}

		cout << angle << endl;
		cout << sin(angle) << endl;
		cout << x << ", " << z << endl;
	glutPostRedisplay();
}
//////////////////////////////////////IDLE FUNCTION
void idle() {
	if (a_key_down == true) exit(0); //if user pressed q, wait for idle function to handle it
}

void DrawTeapot() {
	glPushMatrix();
	glBindTexture(GL_TEXTURE_2D, 2004);
	glTranslated(-640, 0, -360);
	spinner(2);
	glRotated(x2Angle, 1.0, 0.0, 0.0); // x-roll
	glRotated(y2Angle, 0.0, 1.0, 0.0); // y-roll
	glutSolidTeapot(50);
	glPopMatrix();
}

void DrawTeacup() {
	glPushMatrix();
	glBindTexture(GL_TEXTURE_2D, 2005);
	glTranslated(0, 0, -360);
	//spinner(2);
	glRotated(x2Angle, 1.0, 0.0, 0.0); // x-roll
	glRotated(y2Angle, 0.0, 1.0, 0.0); // y-roll
	glutSolidTeacup(50);
	glPopMatrix();
}

void DrawTeaSpoon() {
	glPushMatrix();
	glBindTexture(GL_TEXTURE_2D, 2006);
	glTranslated(640, 0, -640);
	//spinner(2);
	glRotated(x2Angle, 1.0, 0.0, 0.0); // x-roll
	glRotated(y2Angle, 0.0, 1.0, 0.0); // y-roll
	glutSolidTeaspoon(100);
	glPopMatrix();
}


///////////////////////////////////////////DRAW THE WALLS FUNCTION
void Walls() {

		//GRAY WALL COLOR DIFFUSE
		GLfloat mat_diffuse[] = { .7, .7, .7 };
		glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
		glPushMatrix();
		glBegin(GL_QUADS);
		// Floor
		glNormal3f(1.0f, 1.0f, 1.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(-1000, -50, -1000);
		glTexCoord2f(20.0, 0.0); glVertex3f(-1000, -50, 1000);
		glTexCoord2f(20.0, 20.0); glVertex3f(1000, -50, 1000);
		glTexCoord2f(0.0, 20.0); glVertex3f(1000, -50, -1000);
		glEnd();

		glBindTexture(GL_TEXTURE_2D, 2001);
		glBegin(GL_QUADS);
		// Ceiling
		glNormal3f(1.0f, 1.0f, 1.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(-1000, 50, -1000);
		glTexCoord2f(20.0, 0.0); glVertex3f(-1000, 50, 1000);
		glTexCoord2f(20.0, 20.0); glVertex3f(1000, 50, 1000);
		glTexCoord2f(0.0, 20.0); glVertex3f(1000, 50, -1000);
		glEnd();

		glBindTexture(GL_TEXTURE_2D, 2002);
		glBegin(GL_QUADS);
		// Walls
		glNormal3f(0.0f, 1.0f, 1.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(-800, -50, -800);
		glTexCoord2f(1.0, 0.0); glVertex3f(-800, 50, -800);	//LEFT
		glTexCoord2f(1.0, 20.0); glVertex3f(-800, 50, 800);
		glTexCoord2f(0.0, 20.0); glVertex3f(-800, -50, 800);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(800, -50, -800);
		glTexCoord2f(1.0, 0.0); glVertex3f(800, 50, -800);	//Right
		glTexCoord2f(1.0, 20.0); glVertex3f(800, 50, 800);
		glTexCoord2f(0.0, 20.0); glVertex3f(800, -50, 800);

		glNormal3f(0.0f, 0.0f, -1.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(-800, -50, 800);
		glTexCoord2f(1.0, 0.0); glVertex3f(-800, 50, 800);	//Back 1
		glTexCoord2f(1.0, 10.0); glVertex3f(-160, 50, 800);
		glTexCoord2f(0.0, 10.0); glVertex3f(-160, -50, 800);

		glNormal3f(0.0f, 0.0f, -1.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(160, -50, 800);
		glTexCoord2f(1.0, 0.0); glVertex3f(160, 50, 800);	//Back 2
		glTexCoord2f(1.0, 10.0); glVertex3f(800, 50, 800);
		glTexCoord2f(0.0, 10.0); glVertex3f(800, -50, 800);

		glNormal3f(0.0f, 1.0f, 1.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(-800, -50, -800);
		glTexCoord2f(1.0, 0.0); glVertex3f(-800, 50, -800);	//Front 1
		glTexCoord2f(1.0, 10.0); glVertex3f(-160, 50, -800);
		glTexCoord2f(0.0, 10.0); glVertex3f(-160, -50, -800);

		glNormal3f(0.0f, 1.0f, 1.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(160, -50, -800);
		glTexCoord2f(1.0, 0.0); glVertex3f(160, 50, -800);	//Front 2
		glTexCoord2f(1.0, 10.0); glVertex3f(800, 50, -800);
		glTexCoord2f(0.0, 10.0); glVertex3f(800, -50, -800);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(-480, -50, 800);
		glTexCoord2f(1.0, 0.0); glVertex3f(-480, 50, 800);	//V1
		glTexCoord2f(1.0, 5.0); glVertex3f(-480, 50, 480);
		glTexCoord2f(0.0, 5.0); glVertex3f(-480, -50, 480);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(160, -50, 800);
		glTexCoord2f(1.0, 0.0); glVertex3f(160, 50, 800);	//V2
		glTexCoord2f(1.0, 5.0); glVertex3f(160, 50, 480);
		glTexCoord2f(0.0, 5.0); glVertex3f(160, -50, 480);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(-160, -50, -800);
		glTexCoord2f(1.0, 0.0); glVertex3f(-160, 50, -800);	//V3
		glTexCoord2f(1.0, 15.0); glVertex3f(-160, 50, 480);
		glTexCoord2f(0.0, 15.0); glVertex3f(-160, -50, 480);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(480, -50, -800);
		glTexCoord2f(1.0, 0.0); glVertex3f(480, 50, -800);	//V4
		glTexCoord2f(1.0, 15.0); glVertex3f(480, 50, 480);
		glTexCoord2f(0.0, 15.0); glVertex3f(480, -50, 480);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(-480, -50, -480);
		glTexCoord2f(1.0, 0.0); glVertex3f(-480, 50, -480);	//V5
		glTexCoord2f(1.0, 5.0); glVertex3f(-480, 50, -160);
		glTexCoord2f(0.0, 5.0); glVertex3f(-480, -50, -160);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(160, -50, -480);
		glTexCoord2f(1.0, 0.0); glVertex3f(160, 50, -480);	//V6
		glTexCoord2f(1.0, 5.0); glVertex3f(160, 50, -160);
		glTexCoord2f(0.0, 5.0); glVertex3f(160, -50, -160);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(-480, -50, 160);
		glTexCoord2f(1.0, 0.0); glVertex3f(-480, 50, 160);	//H1
		glTexCoord2f(1.0, 5.0); glVertex3f(-160, 50, 160);
		glTexCoord2f(0.0, 5.0); glVertex3f(-160, -50, 160);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(160, -50, 160);
		glTexCoord2f(1.0, 0.0); glVertex3f(160, 50, 160);	//H2
		glTexCoord2f(1.0, 5.0); glVertex3f(480, 50, 160);
		glTexCoord2f(0.0, 5.0); glVertex3f(480, -50, 160);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(-800, -50, -160);
		glTexCoord2f(1.0, 0.0); glVertex3f(-800, 50, -160);	//H3
		glTexCoord2f(1.0, 5.0); glVertex3f(-480, 50, -160);
		glTexCoord2f(0.0, 5.0); glVertex3f(-480, -50, -160);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0, 0.0); glVertex3f(-160, -50, -480);
		glTexCoord2f(1.0, 0.0); glVertex3f(-160, 50, -480);	//H4
		glTexCoord2f(1.0, 5.0); glVertex3f(160, 50, -480);
		glTexCoord2f(0.0, 5.0); glVertex3f(160, -50, -480);

		glEnd();
		glPopMatrix();

	
		glPushMatrix();
		glBindTexture(GL_TEXTURE_2D, 2006);
		glRotated(y2Angle, 0.0, 1.0, 0.0); // x-roll
		glutSolidTeapot(3000);
		glPopMatrix();


}
////////////////////////////////////DISPLAY FUNCTION
void display()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0, 640.0 / 480, 1.0, 5000.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	gluLookAt(x, 1.0, z, x + lx, 1.0 + ly, z + lz, 0.0, 1.0, 0.0);

	GLfloat lightIntensity[] = { 1.0, 1.0f, 1.0f, 0.0f };
	GLfloat light_position[] = { 0.0f, 1000.0f, 0.0f, 1.0f };
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightIntensity);
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
	
	DrawTeacup();
	DrawTeapot();
	DrawTeaSpoon();
	glBindTexture(GL_TEXTURE_2D, 2003);
	Walls();

	glutPostRedisplay();
	glutSwapBuffers();

	if (firstrun == true) firstrun = false;
	}

int main(int argc, char** argv)
{
	
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutCreateWindow("Maze");
	glutInitWindowPosition(10, 10);
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	glutSpecialFunc(SpecialInput);
	glutIdleFunc(idle);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_TEXTURE_2D);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_DEPTH_TEST); // hidden surface removal
	glEnable(GL_NORMALIZE); // normalize vectors for proper shading
	srand(time(0));
	pix[1].readBMPFile("gravel512.bmp");  // make pixmap from image
	pix[1].setTexture(2002);		// create texture
	pix[0].readBMPFile("ceiling.bmp");
	pix[0].setTexture(2001);
	pix[2].readBMPFile("floor.bmp");
	pix[2].setTexture(2003);
	pix[3].readBMPFile("mandrill.bmp");
	pix[3].setTexture(2006);
	pix[4].readBMPFile("monkey.bmp");
	pix[4].setTexture(2005);
	pix[5].readBMPFile("monkey2.bmp");
	pix[5].setTexture(2004);
	glutMainLoop();


	return 0;
}


